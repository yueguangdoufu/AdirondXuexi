package com.lsnu.train.intent3;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btn1=findViewById(R.id.button1);
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Intent intent=new Intent(MainActivity.this,SlaveActivity.class);
                Intent intent=new Intent();
                intent.setAction("testaction1");
                intent.addCategory("testcat");
                intent.addCategory("android.intent.category.DEFAULT");
                String uriStr="testprotocl://www.lsnu.edu.cn:888/a1/a12";
                Uri data=Uri.parse(uriStr);
                intent.setData(data);
                startActivity(intent);
            }
        });


    }
}
